import React, { Component } from 'react';
import './MainDiv.css';

class MainDiv extends Component {
    render() {
        return(
            <div id="mainDiv">
                <span><p><strong>CHART</strong></p></span>
            </div>
        );
    }
}

export default MainDiv;